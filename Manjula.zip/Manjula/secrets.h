#define SECRET_SSID "Sukul'S Realme"    // replace MySSID with your WiFi network name
#define SECRET_PASS "m82bm1887" // replace MyPassword with your WiFi password

#define SECRET_CH_ID 2301850     // replace 0000000 with your channel number
#define SECRET_WRITE_APIKEY "NRFP58SBVEYZR7AO"   // replace XYZ with your channel write API Key
